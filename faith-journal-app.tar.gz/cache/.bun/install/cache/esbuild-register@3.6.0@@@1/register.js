require('./dist/node.js').register({
  target: `node${process.version.slice(1)}`,
})
