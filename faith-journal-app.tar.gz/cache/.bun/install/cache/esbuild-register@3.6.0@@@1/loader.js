module.exports = require('./dist/loader.js')
