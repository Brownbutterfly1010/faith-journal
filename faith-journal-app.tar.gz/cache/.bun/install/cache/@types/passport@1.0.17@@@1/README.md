# Installation
> `npm install --save @types/passport`

# Summary
This package contains type definitions for passport (http://passportjs.org).

# Details
Files were exported from https://github.com/DefinitelyTyped/DefinitelyTyped/tree/master/types/passport.

### Additional Details
 * Last updated: Mon, 28 Oct 2024 20:34:09 GMT
 * Dependencies: [@types/express](https://npmjs.com/package/@types/express)

# Credits
These definitions were written by [Horiuchi_H](https://github.com/horiuchi), [Eric Naeseth](https://github.com/enaeseth), [Igor Belagorudsky](https://github.com/theigor), [Tomek Łaziuk](https://github.com/tlaziuk), [Daniel Perez Alvarez](https://github.com/unindented), [Kevin Stiehl](https://github.com/kstiehl), and [Oleg Vaskevich](https://github.com/vaskevich).
