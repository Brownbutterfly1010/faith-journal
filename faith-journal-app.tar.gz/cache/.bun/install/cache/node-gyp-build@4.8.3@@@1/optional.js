#!/usr/bin/env node

/*
I am only useful as an install script to make node-gyp not compile for purely optional native deps
*/

process.exit(0)
