module.exports = require.addon.bind(require)
