# `react-alert-dialog`

## Installation

```sh
$ yarn add @radix-ui/react-alert-dialog
# or
$ npm install @radix-ui/react-alert-dialog
```

## Usage

View docs [here](https://radix-ui.com/primitives/docs/components/alert-dialog).
