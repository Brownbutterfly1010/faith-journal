# `react-use-controllable-state`

## Installation

```sh
$ yarn add @radix-ui/react-use-controllable-state
# or
$ npm install @radix-ui/react-use-controllable-state
```

## Usage

This is an internal utility, not intended for public usage.
