# `react-focus-scope`

## Installation

```sh
$ yarn add @radix-ui/react-focus-scope
# or
$ npm install @radix-ui/react-focus-scope
```

## Usage

This is an internal utility, not intended for public usage.
