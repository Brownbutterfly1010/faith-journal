# `react-progress`

## Installation

```sh
$ yarn add @radix-ui/react-progress
# or
$ npm install @radix-ui/react-progress
```

## Usage

View docs [here](https://radix-ui.com/primitives/docs/components/progress).
