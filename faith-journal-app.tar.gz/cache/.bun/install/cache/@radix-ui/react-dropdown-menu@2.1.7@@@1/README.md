# `react-dropdown-menu`

## Installation

```sh
$ yarn add @radix-ui/react-dropdown-menu
# or
$ npm install @radix-ui/react-dropdown-menu
```

## Usage

View docs [here](https://radix-ui.com/primitives/docs/components/dropdown-menu).
