# `react-portal`

## Installation

```sh
$ yarn add @radix-ui/react-portal
# or
$ npm install @radix-ui/react-portal
```

## Usage

View docs [here](https://radix-ui.com/primitives/docs/utilities/portal).
