# `react-accordion`

## Installation

```sh
$ yarn add @radix-ui/react-accordion
# or
$ npm install @radix-ui/react-accordion
```

## Usage

View docs [here](https://radix-ui.com/primitives/docs/components/accordion).
