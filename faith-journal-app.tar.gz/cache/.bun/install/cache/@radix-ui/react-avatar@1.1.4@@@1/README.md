# `react-avatar`

## Installation

```sh
$ yarn add @radix-ui/react-avatar
# or
$ npm install @radix-ui/react-avatar
```

## Usage

View docs [here](https://radix-ui.com/primitives/docs/components/avatar).
