# `react-visually-hidden`

## Installation

```sh
$ yarn add @radix-ui/react-visually-hidden
# or
$ npm install @radix-ui/react-visually-hidden
```

## Usage

View docs [here](https://radix-ui.com/primitives/docs/utilities/visually-hidden).
