# `react-navigation-menu`

## Installation

```sh
$ yarn add @radix-ui/react-navigation-menu
# or
$ npm install @radix-ui/react-navigation-menu
```

## Usage

View docs [here](https://radix-ui.com/primitives/docs/components/navigation-menu).
