# `react-aspect-ratio`

## Installation

```sh
$ yarn add @radix-ui/react-aspect-ratio
# or
$ npm install @radix-ui/react-aspect-ratio
```

## Usage

View docs [here](https://radix-ui.com/primitives/docs/utilities/aspect-ratio).
