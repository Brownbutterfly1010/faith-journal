# `react-toggle`

## Installation

```sh
$ yarn add @radix-ui/react-toggle
# or
$ npm install @radix-ui/react-toggle
```

## Usage

View docs [here](https://radix-ui.com/primitives/docs/components/toggle).
