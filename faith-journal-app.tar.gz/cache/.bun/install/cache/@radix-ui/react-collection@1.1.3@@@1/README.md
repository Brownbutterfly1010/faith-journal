# `react-collection`

## Installation

```sh
$ yarn add @radix-ui/react-collection
# or
$ npm install @radix-ui/react-collection
```

## Usage

This is an internal utility, not intended for public usage.
