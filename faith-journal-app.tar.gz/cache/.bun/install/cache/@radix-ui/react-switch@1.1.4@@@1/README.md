# `react-switch`

## Installation

```sh
$ yarn add @radix-ui/react-switch
# or
$ npm install @radix-ui/react-switch
```

## Usage

View docs [here](https://radix-ui.com/primitives/docs/components/switch).
