# `react-toggle-group`

## Installation

```sh
$ yarn add @radix-ui/react-toggle-group
# or
$ npm install @radix-ui/react-toggle-group
```

## Usage

View docs [here](https://radix-ui.com/primitives/docs/components/toggle-group).
