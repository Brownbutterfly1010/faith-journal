# `react-tabs`

## Installation

```sh
$ yarn add @radix-ui/react-tabs
# or
$ npm install @radix-ui/react-tabs
```

## Usage

View docs [here](https://radix-ui.com/primitives/docs/components/tabs).
