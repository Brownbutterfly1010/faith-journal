# `react-menubar`

## Installation

```sh
$ yarn add @radix-ui/react-menubar
# or
$ npm install @radix-ui/react-menubar
```

## Usage

View docs [here](https://radix-ui.com/primitives/docs/components/menubar).
