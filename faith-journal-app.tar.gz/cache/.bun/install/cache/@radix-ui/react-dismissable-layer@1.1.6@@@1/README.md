# `react-dismissable-layer`

## Installation

```sh
$ yarn add @radix-ui/react-dismissable-layer
# or
$ npm install @radix-ui/react-dismissable-layer
```

## Usage

This is an internal utility, not intended for public usage.
