# `react-arrow`

## Installation

```sh
$ yarn add @radix-ui/react-arrow
# or
$ npm install @radix-ui/react-arrow
```

## Usage

This is an internal utility, not intended for public usage.
