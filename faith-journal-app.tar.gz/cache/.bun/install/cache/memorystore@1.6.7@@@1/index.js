module.exports = require('./lib/memorystore.js')
